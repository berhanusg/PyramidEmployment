package com.pyramidbuildersemployment.models;

public enum RoleName {
    ADMIN,USER,CLIENT;
}
