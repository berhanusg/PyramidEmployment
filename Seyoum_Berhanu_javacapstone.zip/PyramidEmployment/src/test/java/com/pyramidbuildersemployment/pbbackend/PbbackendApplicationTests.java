package com.pyramidbuildersemployment.pbbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PbbackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
